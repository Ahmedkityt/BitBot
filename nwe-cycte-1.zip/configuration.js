module.exports = {
  token: "Nzg3MzY0NjIzOTQyMDI1MjI2.X9T4cg.Fht3XxtarG3mAwB4yNdb8Wlhj68",
  prefix: "@",
  youtubekey: "",
  devs: [" "]
};
